let blockedSites = ["*://www.facebook.com/*", "*://www.youtube.com/*"];

chrome.declarativeNetRequest.updateDynamicRules({
  removeRuleIds: [1, 2],
  addRules: blockedSites.map((site, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: "block" },
    condition: { urlFilter: site }
  }))
});
